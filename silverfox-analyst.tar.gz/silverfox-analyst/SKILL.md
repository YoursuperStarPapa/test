---
name: silverfox-analyst
description: SilverFox（银狐）木马威胁分析与应急响应技能。用于：银狐木马的威胁狩猎（threat hunting）、IoC检测与匹配、SIEM/EDR查询生成（Splunk/Elastic/Sentinel/Falcon/Sigma）、攻击链分析、变种识别、MITRE ATT&CK映射、事件研判、应急响应指导、以及生成标准化分析报告。当用户提到银狐/SilverFox/游蛇/谷堕大盗/UTG-Q-1000/ValleyRAT/银狐木马时触发。
---

# SilverFox Analyst

银狐（SilverFox）木马威胁分析与应急响应技能。

## Quick Start

用户请求银狐相关分析时，按以下流程响应：

1. **明确意图**：判断用户需要什么——威胁狩猎？IoC查询？事件研判？报告生成？
2. **加载参考**：按需读取 `references/` 下的文件
3. **执行分析**：使用对应的工作流
4. **输出结果**：按格式要求交付

## 工作流

### 1. 威胁狩猎（Threat Hunting）

当用户要求检查环境是否受银狐影响：

1. 读取 `references/ioc-database.md` 获取最新IoC
2. 读取 `references/detection-queries.md` 获取对应平台查询
3. 根据用户SIEM/EDR平台（Splunk/Elastic/Sentinel/Falcon），提供适配的查询语句
4. 按优先级排序：端口8880出站 → IE目录异常DLL → 可疑计划任务 → AnyDesk安装 → PowerShell异常

### 2. IoC 匹配与查询

当用户提供文件哈希、域名、IP或文件名：

1. 读取 `references/ioc-database.md`
2. 进行精确或模糊匹配
3. 如匹配成功：输出变种名称、关联攻击活动、建议处置措施
4. 如未匹配：提示可能是新变种，建议上传国家病毒分析平台

### 3. 事件研判（Incident Triage）

当用户报告疑似银狐感染：

1. 询问关键信息：文件名/来源/执行时间/异常现象
2. 读取 `references/ioc-database.md` 比对特征
3. 读取 `references/incident-response.md` 按响应流程指导
4. 判断感染阶段（投递/执行/持久化/C2/横向/诈骗）
5. 给出处置建议

### 4. 分析报告生成

当用户要求生成银狐分析报告：

1. 读取 `assets/report-template.md` 获取模板
2. 根据用户提供的信息填充各section
3. 输出完整Markdown报告

### 5. 变种识别

当用户描述可疑样本行为：

1. 读取 `references/ioc-database.md` 中的变种特征
2. 根据行为特征匹配变种（见下方速查表）
3. 输出变种名称和对应检测方法

#### 变种速查

| 行为特征 | 变种 |
|---|---|
| 静默安装AnyDesk + 无人值守 | AnyDesk联合变种 |
| Python编写 + 窃密后自删除 | Python Stealer |
| 双重持久化（注册表+计划任务）+ 对抗EDR | ABCDoor |
| PowerShell AMSI绕过 + 反射式加载 | Chrome变种 |
| Rust/Go加载器 + 内存Shellcode + 完整远控 | ValleyRAT（基础版） |
| 利用HoldingHands合法远控 | HoldingHands联合变种 |
| SEO投毒 + 伪造下载站 | ValleyRAT SEO变种 |

## 参考文件导航

| 文件 | 内容 | 何时读取 |
|---|---|---|
| `references/ioc-database.md` | 全量IoC（哈希/域名/IP/URL/文件名/路径/计划任务/注册表） | 每次分析必读 |
| `references/detection-queries.md` | 7平台检测查询 + Sigma/YARA规则 | 需要写检测规则或查询时 |
| `references/mitre-mapping.md` | 完整MITRE ATT&CK映射 | 需要ATT&CK矩阵或战术分析时 |
| `references/incident-response.md` | 应急响应8步流程 + 根治方案 | 处理感染事件时 |
| `assets/report-template.md` | 标准化分析报告模板 | 生成报告时 |

## 关键判断准则

### 确认银狐感染的强信号

- `C:\Program Files\Internet Explorer\` 下存在非系统DLL（log.dll等）
- 端口8880的出站HTTP连接
- 计划任务名包含"Adobe Updater"/"Windows Update"且执行频率≤5分钟
- 未安装AnyDesk但存在AnyDesk进程
- 父进程为IM工具（微信/企微/QQ）的.exe执行
- 文件名含"违纪/裁员/补偿/稽查"且为可执行文件

### 排除银狐的条件

- 无上述强信号
- 可疑文件经多引擎检测无银狐关联
- 网络连接目标为已知合法服务

## 国家平台

可疑样本可上传至国家计算机病毒协同分析平台进行多引擎检测：
- https://virus.cverc.org.cn
