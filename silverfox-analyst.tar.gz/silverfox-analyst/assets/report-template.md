# SilverFox — 银狐木马的进程之路

> **TL;DR** — SilverFox（银狐）是一个长期针对国内政企用户的远程控制木马家族，通过"极致社会工程学 + 合法软件滥用 + 产业化分工"模式，以"违纪名单""裁员补偿"等社工诱饵投递恶意程序，利用白加黑加载、进程注入、无文件攻击等技术实现隐蔽驻留，最终冒充领导实施诈骗或窃取敏感数据。2026年上半年攻击事件同比增长127%，已导致超过1.2万家企业中招。

| Field | Detail |
|---|---|
| **Threat Name** | SilverFox（银狐）/ 游蛇 / 谷堕大盗 / UTG-Q-1000 |
| **Malware Family** | ValleyRAT / AtlasCross RAT / Python Stealer / ABCDoor |
| **CVSS (if CVE)** | N/A — 黑产攻击活动，非单一漏洞 |
| **Affected Platform** | Windows (全版本) |
| **Threat Actor** | SilverFox 黑产团伙（产业化分工，非传统APT） |
| **First Observed** | 2020年，2025-2026年大规模活跃 |
| **Report Date** | 2026-05-21（国家计算机病毒应急处理中心预警） |
| **Confidence Level** | High — 多厂商联合确认，国家平台实证 |
| **Tags** | `远控木马` `社会工程学` `白加黑` `进程注入` `无文件攻击` `电信诈骗` `LotL` |

---

## 0 · Background — 银狐溯源与变种演化史

> *银狐从何而来？它经历了怎样的进化？*

### 0.1 起源：谁创造了银狐？

银狐（Silver Fox）**并非国家级APT组织**，而是一个以**经济利益为首要驱动力**的黑灰产犯罪组织。其命名来源于早期木马样本中发现的"PDB路径字符串"——代码中残留了"Silver Fox"相关标识。

| 维度 | 描述 |
|---|---|
| **组织性质** | 黑灰产犯罪组织，以经济利益为驱动（非国家级APT） |
| **命名来源** | 早期样本PDB路径中存在"Silver Fox"字符串 |
| **别称** | 银狐 / 游蛇 / 谷堕大盗 / UTG-Q-1000 / SwimSnake / Void Arachne / Valley Thief |
| **首次披露** | 2020-2021年间，微步在线、奇安信等安全厂商陆续披露 |
| **活跃时间** | 2020年至今，攻击频次逐年递增 |
| **组织规模** | 推测10-50人规模的黑产团伙 |
| **攻击范围** | 初始以中国境内为主，2025年后扩展至印度、日本、马来西亚、菲律宾等亚太地区 |
| **组织架构** | 分为四个子群组运作（NCC Group披露） |

#### NCC Group 披露的四个子群组

| 子群组 | 职能 | 说明 |
|---|---|---|
| **金融组** | 资金窃取与诈骗变现 | 冒充领导转账、窃取银行凭据 |
| **新闻与情感组** | 社工诱饵制作与投放 | 伪造公文、制作钓鱼素材、舆情操控 |
| **设计与制造组** | 木马开发与免杀更新 | 核心开发者，负责ValleyRAT等恶意软件迭代 |
| **"黑水坑"组** | 基础设施运营与数据处理 | C2服务器管理、域名轮换、窃取数据变现 |

#### 核心人员画像（推测）

- **核心开发者**：具备专业软件开发背景，熟悉Windows底层机制（PE结构、内存管理、系统调用）
- **免杀工程师**：对主流安全产品检测引擎有深入研究，持续跟踪安全厂商更新，按周迭代免杀版本
- **社工组**：具备行业知识（财税、政务等），能制作高度逼真的钓鱼素材，甚至能根据企业组织架构跳过安全部门精准投递
- **运营模式**：松耦合、快迭代，各模块独立更新、快速替换，攻击链条完全产业化

### 0.2 变种演化时间线

银狐从2020年至今经历了**五个免杀时代**和**多次重大变种分化**：

```
2020 ──── 首次披露，聚焦财税行业
  │        └─ ValleyRAT 基础远控诞生（Go/Rust加载器 + 内存Shellcode）
  │
2021 ──── 显著上升，扩展至政务、IM投递
  │        ├─ 白加黑（DLL Side-Loading）成为标配
  │        ├─ 引入 mshta.exe / rundll32.exe / regsvr32.exe 白利用
  │        └─ 免杀1.0时代：简单加壳 + 文件属性伪造 + 宏代码混淆
  │
2022 ──── 持续上升，百余变种
  │        ├─ 引入 Direct Syscall + Shellcode 多层加密
  │        ├─ SEO投毒增加（伪造Chrome下载站等）
  │        ├─ Ghost改良版远控（银狐RAT）出现
  │        └─ 免杀2.0时代：白加黑+DLL侧载，大幅绕过静态检测
  │
2023 ──── 高频攻击，数百变种
  │        ├─ 全行业扩散（教育、医疗、制造业、物流）
  │        ├─ 供应链投递出现
  │        ├─ HackBrian RAT 引入
  │        └─ 免杀3.0时代：Direct Syscall + Shellcode多层加密，绕过EDR用户态Hook
  │
2024 ──── 爆发式增长，千余变种
  │        ├─ EDR深度对抗能力成熟
  │        ├─ 无文件攻击成为主流
  │        ├─ ABCDoor 高级持久化变种出现（Python编写，双重持久化）
  │        ├─ AtlasCross RAT 新型远控出现
  │        └─ 免杀4.0时代：Indirect Syscall + ETW/AMSI Patch + Unhooking（APT级EDR绕过）
  │
2025 ──── 持续高位，技术范式转移
  │        ├─ AnyDesk联合诈骗变种成为主流（合法远控武器化）
  │        ├─ Python Stealer 窃密变种出现
  │        ├─ 攻击目标扩展至印度、日本等亚太地区
  │        ├─ 伪造Chrome下载站分发恶意软件
  │        ├─ HoldingHands 合法远控工具被滥用
  │        ├─ "双重间谍"模式出现（间谍+犯罪并行）
  │        └─ 免杀5.0时代：全栈无文件 + Callback执行 + AI辅助免杀
  │
2026 ──── 当前——产业化巅峰
           ├─ 最新变种：Rust加载器 + ValleyRAT + Python后门ABCDoor
           ├─ 攻击事件同比增长127%，超1.2万家企业中招
           ├─ 单笔诈骗金额最高达500万元
           ├─ Chrome变种：PowerShell AMSI绕过 + 反射式加载
           ├─ 仿印度税务部门钓鱼攻击（2025.12-2026.02，1600+恶意邮件）
           └─ 国家病毒中心发布专项预警（2026-05-21）
```

### 0.3 主要变种家族详解

| # | 变种名称 | 首次出现 | 核心技术 | 主要功能 | 活跃状态 |
|---|---|---|---|---|---|
| 1 | **ValleyRAT** | 2020 | Go/Rust加载器 + 内存Shellcode | 完整远控（命令执行、文件管理、屏幕截图、键盘记录） | ✅ 持续活跃，最基础变种 |
| 2 | **Ghost改良版（银狐RAT）** | 2022 | 基于ValleyRAT改良 | 键盘记录、截屏、文件窃取 | ✅ 持续活跃 |
| 3 | **HackBrian RAT** | 2023 | 模块化加载 | 数据窃取、代理隧道搭建 | 🔄 间歇活跃 |
| 4 | **Python Stealer** | 2026.02 | Python编写，PyInstaller打包 | 专注窃密（浏览器密码/Cookie/文件），完成后自删除 | ✅ 新变种 |
| 5 | **AnyDesk联合变种** | 2025 | 银狐+AnyDesk静默安装 | 桌面接管 + 冒充领导诈骗 | ✅ 危害最大变种 |
| 6 | **ABCDoor** | 2025底 | Python，双重持久化（注册表+计划任务） | 对抗EDR，高级持久化，可禁用安全软件 | ✅ 高阶变种 |
| 7 | **AtlasCross RAT** | 2024 | 新型RAT框架 | 远程控制，通过伪造知名软件域名鱼叉攻击 | ✅ 活跃 |
| 8 | **Chrome变种** | 2026.05 | PowerShell AMSI绕过 + 反射式加载 | 无文件攻击，反沙箱（network_disable），高熵DLL | ✅ 最新变种 |
| 9 | **HoldingHands联合变种** | 2025 | 银狐+HoldingHands合法远控 | 降低技术指纹，利用合法工具横向移动 | ✅ 活跃 |

### 0.4 免杀技术演进五代

| 时代 | 时间段 | 核心手段 | 绕过能力 |
|---|---|---|---|
| **1.0** | 2020-2021H1 | 简单加壳、文件属性伪造、宏代码混淆 | 可被主流AV静态+动态检测 |
| **2.0** | 2021H2-2022H1 | 白加黑 + DLL侧载成为标配 | 大幅绕过静态检测，利用白程序信誉 |
| **3.0** | 2022H2-2023H1 | Direct Syscall + Shellcode多层加密 | 绕过EDR用户态Hook |
| **4.0** | 2023H2-2024 | Indirect Syscall + ETW/AMSI Patch + Unhooking | APT级EDR绕过，行为监控被削弱 |
| **5.0** | 2024-2026 | 全栈无文件 + Callback执行 + AI辅助免杀 | 传统安全产品检测面临极大挑战 |

### 0.5 "双重间谍"模式（2025-2026新趋势）

Sekoia在2026年3月披露，银狐已从单一的经济犯罪演变为**"双重间谍（Dual Espionage）"模式**，同时运行两套并行逻辑：

| 维度 | 战略情报线 | 机会主义犯罪线 |
|---|---|---|
| **目标** | 特定目标（如台湾机构、印度政府部门） | 广泛的金融、税务相关行业 |
| **时机** | 特定时间窗口（如税务审计期） | 全年持续攻击 |
| **目的** | 获取敏感政治或经济情报 | 窃取资金或凭证变现 |
| **工具** | 定制化ValleyRAT + 高级持久化 | Python Stealer + 合法远控 |
| **投递** | 精准鱼叉式钓鱼 | 批量IM投递 + SEO投毒 |

> 这种双重结构使得传统的基于单一动机的威胁狩猎变得困难——防御者很难通过单一指标覆盖其全部活动。

---

## 1 · The Findings

> *What happened — 银狐木马攻击活动的完整技术剖析。*

### 1.1 Executive Summary

2026年上半年，国家计算机病毒应急处理中心和计算机病毒防治技术国家工程实验室依托国家计算机病毒协同分析平台，捕获了大量文件名包含"内部调查结果""违纪名单""裁员补偿"等词汇的恶意程序。经分析确认，这些样本均为SilverFox（银狐）木马的最新变种。

银狐家族的核心设计哲学是**"低技术门槛、高社工诱导、快变现周期"**：不依赖零日漏洞，而是通过精准的社会工程学获取初始访问；广泛利用系统自带工具和合法软件（Living off the Land）执行恶意代码；攻击成功后快速实施诈骗或窃密。其攻击链条已完全产业化——从木马开发、免杀更新、诱饵制作到批量投递、远程控制、诈骗变现，每个环节都有专业团队负责。

银狐的主要危害体现在四个方面：**冒充领导诈骗**（控制受害者微信/企微后向财务下达转账指令）、**敏感信息窃取**（浏览器密码、Cookie、财务数据）、**远程控制与监控**（屏幕、键盘、摄像头）、**僵尸网络与二次攻击**（作为跳板渗透内网）。单笔诈骗金额最高达500万元。

### 1.2 Attack Timeline

| 阶段 | 时间窗口 | 事件描述 |
|---|---|---|
| **Initial Access** | T+0 min | 攻击者通过微信/企业微信/QQ群聊发送伪装文件（如"2026年第二季度违纪名单.zip"） |
| **User Execution** | T+0~5 min | 用户解压后双击伪装成文件夹/PDF的.exe文件，弹出虚假错误提示，木马后台执行 |
| **Defense Evasion** | T+5~10 sec | 环境检测：反虚拟机（50+特征）、反沙箱、检测杀软；检测不通过则终止 |
| **Execution** | T+10~30 sec | 六级加载链启动：诱饵 → 加载器(Rust/Go) → 白利用(mshta/rundll32) → Shellcode(内存) → 远控核心 → 功能插件 |
| **Persistence** | T+30~60 sec | 创建伪装计划任务（"Adobe Updater"）、注册表Run键、系统服务，2-3种机制并行 |
| **C2 Communication** | T+1~2 min | AES-256加密通信，端口8880，上报系统信息，等待指令 |
| **Collection & Impact** | T+2~30 min | 窃取浏览器密码/Cookie、静默安装AnyDesk、屏幕监控、键盘记录 |
| **Lateral Movement** | T+30 min+ | 扫描内网存活主机，弱密码爆破，通过已控IM账号向同事发送钓鱼文件 |
| **Fraud/Exfiltration** | T+1~24 hr | 冒充领导向财务下达转账指令，或打包窃取数据上传C2 |

### 1.3 Technical Deep Dive

#### Exploit Mechanism

**Root Cause:** 银狐不依赖单一漏洞，而是利用**人性弱点 + 合法信任链**的组合攻击：

1. **社会工程学精准投递**：文件名伪装为"XX季度违纪名单""通报人员信息""裁员名单""补偿方案"，图标伪装为文件夹/快捷方式/回收站，并添加"pdf"后缀。利用Windows默认隐藏已知文件扩展名的特性，用户看到的是"违纪名单"而非"违纪名单.exe"。

2. **白加黑加载（White-Listing Bypass）**：
   - 投放阶段：在 `C:\Program Files\Internet Explorer\` 下投放 `log.dll` 等载荷
   - 利用合法的 `installer.exe`（白文件）加载恶意 `log.dll`
   - 系统工具滥用：`mshta.exe`、`rundll32.exe`、`regsvr32.exe`、`powershell.exe`

3. **无文件攻击（Fileless）**：PowerShell框架直接在内存中加载.NET CLR，Shellcode加密后内存解执行，不写入磁盘。

4. **进程注入**：反射式DLL注入、APC注入、进程空心化，将恶意代码注入 `explorer.exe`、`svchost.exe`、`sihost.exe` 等系统进程。

5. **合法远控工具武器化**：静默安装AnyDesk并设置无人值守访问，利用其数字签名和成熟远控能力绕过安全检测。

**Attack Vector:** 网络投递（即时通讯工具 + 钓鱼邮件）→ 本地执行（用户点击）→ 远程控制（C2）

**Exploitation Chain:**
```
[社工诱饵] → [用户点击.exe] → [环境检测]
    ↓
[加载器(Rust/Go)] → [白文件installer.exe加载log.dll]
    ↓
[Shellcode内存执行] → [远控核心(ValleyRAT)]
    ↓
[计划任务+注册表持久化] → [C2通信:8880/AES-256]
    ↓
[AnyDesk静默安装] → [屏幕控制] → [冒充领导诈骗]
```

#### Indicators of Compromise (IoCs)

| Type | Value | Context |
|---|---|---|
| **File Name Pattern** | `2026*违纪*名单*.exe`, `*裁员*补偿*.exe`, `*内部调查*.exe` | 诱饵文件命名模式 |
| **File Path** | `C:\Program Files\Internet Explorer\log.dll` | 白利用载荷投递路径 |
| **File Path** | `C:\Program Files\Internet Explorer\installer.exe` | 白文件加载器 |
| **File Hash (MD5)** | `18685800b70e3e30f54d1a5fa1c4b080` | 诱饵样本 |
| **File Hash (MD5)** | `e28fee7fccbab8e743d953383a52c8e4` | 诱饵样本 |
| **File Hash (MD5)** | `245aee2442aab596271add1f62099ec0` | 诱饵样本 |
| **File Hash (MD5)** | `6d51a96545f8a3e15308ef8683f64077` | 诱饵样本 |
| **File Hash (MD5)** | `cb9e0290c31a6cbc2c04eaa010c49c62` | 诱饵样本 |
| **File Hash (MD5)** | `8f785cb7955fb2d7b0914fc8e1e85e1a` | 诱饵样本 |
| **File Hash (MD5)** | `365d79c4976c4266e8a928a291ce70bd` | 诱饵样本 |
| **File Hash (MD5)** | `803fe35653cb4018b56d27e5e130c2d2` | 诱饵样本 |
| **File Hash (MD5)** | `44b2de1f5d9c40947ecf0b5bc6ade7c5` | 诱饵样本 |
| **File Hash (MD5)** | `02ff385debe958e1125fae9191579b87` | 诱饵样本 |
| **File Hash (MD5)** | `52f76f79bf8bd301bad98d73e52c9bca` | 诱饵样本 |
| **File Hash (MD5)** | `dc76c6ff76f78a66e7b242b3a02836c6` | 诱饵样本 |
| **File Hash (MD5)** | `04386776404ca093758217563c1777b3` | 诱饵样本 |
| **File Hash (MD5)** | `6caeaf0e58bb53ca6493ec177090fe37` | 诱饵样本 |
| **Domain** | `gi***ks.cn` | C2 域名 |
| **Domain** | `eea*****fbng.cn` | C2 域名 |
| **Domain** | `ccc******gnsd.cn` | C2 域名 |
| **Domain** | `wwn******dsrf.cn` | C2 域名 |
| **Domain** | `tyr*****rbvv.cn` | C2 域名 |
| **Domain** | `ttc***jiue.cn` | C2 域名 |
| **Domain** | `tts****gsdf.cn` | C2 域名 |
| **URL Pattern** | `http://[域名]:8880/` | C2 回联地址 |
| **URL Pattern** | `http://[域名]:8880/getinstall64` | C2 载荷下载 |
| **IP Address** | `95.*.*.166`, `154.*.*.180`, `154.*.*.78` | C2 基础设施 |
| **IP Address** | `38.*.*.243`, `18.*.*.122`, `95.*.*.247` | C2 基础设施 |
| **IP Address** | `20.*.*.9`, `43.*.*.243`, `16.*.*.143` | C2 基础设施 |
| **IP Address** | `95.*.*.178` | C2 基础设施 |
| **Scheduled Task Name** | `Adobe Updater`, `Windows Update`, `System Check` | 持久化计划任务 |
| **PDB Path** | `XiaobaoService.pdb` | Chrome变种特征 |
| **Process** | `ABoxHeadless.exe` | 变种关联进程 |
| **DLL** | `qimei.dll` | 变种关联DLL |

#### MITRE ATT&CK Mapping

| Tactic | Technique | ID | Description |
|---|---|---|---|
| **Initial Access** | Phishing: Spearphishing via Service | T1566.003 | 通过微信/QQ/企微发送钓鱼文件 |
| **Execution** | User Execution: Malicious File | T1204.002 | 用户双击伪装成文档的exe |
| **Execution** | Command and Scripting Interpreter: PowerShell | T1059.001 | 内存加载.NET CLR执行恶意代码 |
| **Defense Evasion** | Process Injection | T1055 | 反射式DLL注入/APC注入/进程空心化 |
| **Defense Evasion** | Masquerading | T1036 | 文件名伪装（加pdf后缀、图标伪装） |
| **Defense Evasion** | Signed Binary Proxy Execution | T1218 | 白加黑：利用installer.exe加载恶意DLL |
| **Defense Evasion** | Indicator Removal | T1070 | 攻击结束后卸载AnyDesk、清除痕迹 |
| **Defense Evasion** | Virtualization/Sandbox Evasion | T1497 | 检测50+虚拟机/沙箱特征 |
| **Persistence** | Scheduled Task/Job | T1053.005 | 创建伪装计划任务，每1-5分钟执行 |
| **Persistence** | Boot or Logon Autostart Execution: Registry Run Keys | T1547.001 | HKCU/HKLM Run键持久化 |
| **Persistence** | Create or Modify System Process | T1543.003 | 创建随机名称系统服务 |
| **Discovery** | System Network Configuration Discovery | T1016 | 上报IP、计算机名、系统版本 |
| **Discovery** | Remote System Discovery | T1018 | 内网存活主机扫描 |
| **Credential Access** | Credentials from Password Stores | T1555 | 窃取浏览器保存的密码/Cookie |
| **Collection** | Screen Capture | T1113 | 屏幕监控与截图 |
| **Collection** | Input Capture: Keylogging | T1056.001 | 键盘记录 |
| **Command and Control** | Encrypted Channel | T1573 | AES-256加密C2通信 |
| **Command and Control** | Non-Standard Port | T1571 | 端口8880 |
| **Command and Control** | Remote Access Software | T1219 | 静默安装AnyDesk实现远控 |
| **Exfiltration** | Exfiltration Over C2 Channel | T1041 | 窃取数据通过C2上传 |

---

## 2 · The Hunt

> *How to check your blast radius — 针对银狐木马的威胁狩猎方法论。*

### 2.1 Hunt Hypotheses

| # | Hypothesis | Confidence | Rationale |
|---|---|---|---|
| H1 | 组织内存在通过IM工具接收并执行伪装成文档的可执行文件的行为 | High | 银狐90%以上通过微信/企微/QQ投递 |
| H2 | 存在`C:\Program Files\Internet Explorer\`目录下异常DLL文件（如log.dll） | High | 本次预警明确的白利用载荷路径 |
| H3 | 系统关键进程（explorer.exe/svchost.exe）存在异常出站HTTPS连接至端口8880 | High | C2回联特征端口 |
| H4 | 存在伪装成"Adobe Updater"/"Windows Update"的高频计划任务 | Medium | 银狐偏好持久化方式 |
| H5 | 终端静默安装了AnyDesk/TeamViewer等合法远控软件 | Medium | AnyDesk联合诈骗变种特征 |
| H6 | PowerShell进程存在内存加载.NET CLR的异常行为 | Medium | 无文件攻击特征 |
| H7 | 存在高熵.text节且导入函数极少的DLL | Medium | 银狐Chrome变种特征 |

### 2.2 Telemetry Sources Required

- [x] **EDR 进程树 & 文件事件** — 关键：进程父子关系、DLL加载、文件创建
- [x] **防火墙/代理日志** — 出站连接目标IP/域名/端口
- [x] **DNS 查询日志** — DGA域名识别
- [x] **Windows 计划任务日志** — Event ID 106/140/200/201
- [x] **Windows PowerShell 日志** — Event ID 4103/4104（脚本块日志）
- [x] **Windows Sysmon** — Event ID 1(进程创建)/3(网络连接)/7(DLL加载)/11(文件创建)/12-13(注册表)
- [x] **Active Directory 认证日志** — 横向移动检测
- [x] **即时通讯工具审计日志** — 文件传输记录（如有企业版审计）
- [ ] 网络全流量捕获（PCAP）— 可选，用于深度协议分析

### 2.3 Detection Queries

#### Splunk — 检测伪装文件执行

```spl
index=sysmon EventCode=1
| where ParentImage IN ("*explorer.exe", "*wechat.exe", "*wxwork.exe", "*qq.exe")
| where (Image LIKE "%.exe" AND (
    match(OriginalFileName, "(?i)(名单|违纪|裁员|补偿|稽查|通报|调查)")
    OR match(CommandLine, "(?i)(名单|违纪|裁员|补偿|稽查|通报|调查)")
))
| stats count by Computer, User, ParentImage, Image, CommandLine, Hashes
```

#### Splunk — 检测白利用路径异常DLL

```spl
index=sysmon EventCode=7
| where ImageLoaded LIKE "C:\\Program Files\\Internet Explorer\\%"
| where NOT match(ImageLoaded, "(?i)(ieproxy\.dll|iertutil\.dll)")
| stats count by Computer, Image, ImageLoaded, Signed, Signature
```

#### Splunk — 检测C2回联（端口8880）

```spl
index=firewall OR index=proxy dest_port=8880
| stats count values(dest_ip) as dest_ips by src_ip
| where count > 3
```

#### Splunk — 检测可疑计划任务创建

```spl
index=sysmon EventCode=1 Image="*schtasks.exe"
| regex(CommandLine, "(?i)(Adobe Updater|Windows Update|System Check|Security Update)")
| stats count by Computer, User, CommandLine, ParentImage
```

#### Elastic (KQL) — 检测AnyDesk静默安装

```kql
event.dataset: * AND (
  process.name: "AnyDesk.exe" AND
  process.command_line: ("--install" OR "--start-with-win" OR "--silent")
)
```

#### Microsoft Sentinel (KQL) — 检测进程注入到系统进程

```kql
DeviceProcessEvents
| where FileName in~ ("mshta.exe", "rundll32.exe", "regsvr32.exe")
| where InitiatingProcessFileName !~ "explorer.exe"
| join kind=inner DeviceNetworkEvents on DeviceId, InitiatingProcessId
| where RemotePort == 8880 or RemotePort == 443
| project Timestamp, DeviceName, FileName, InitiatingProcessFileName, RemoteIP, RemotePort
```

#### CrowdStrike Falcon — 检测高熵DLL加载

```
#event_simpleName=LoadImage
| ImageLoaded=*\Internet Explorer\*.dll
| groupBy([aid, ComputerName, ImageLoaded], function=([count(aid)]))
```

#### Sigma Rule — SilverFox 诱饵执行检测

```yaml
title: SilverFox - Suspicious Executable Masquerading as Document
id: a1b2c3d4-e5f6-7890-abcd-ef1234567890
status: experimental
description: Detects execution of executable files with document-related keywords in name, characteristic of SilverFox social engineering attacks
references:
  - https://www.cverc.org.cn/head/zhaiyao/news20260521-yhyj.htm
author: Security Analyst
date: 2026-06-11
logsource:
  category: process_creation
  product: windows
detection:
  selection_keywords:
    CommandLine|contains:
      - '违纪'
      - '裁员'
      - '补偿'
      - '稽查'
      - '通报'
      - '调查结果'
      - '人员信息'
  selection_extension:
    CommandLine|endswith:
      - '.exe'
      - '.scr'
      - '.bat'
  filter_legitimate:
    ParentImage|endswith:
      - '\explorer.exe'
  condition: selection_keywords and selection_extension and not filter_legitimate
level: high
tags:
  - attack.execution
  - attack.t1204.002
  - attack.initial_access
  - attack.t1566.003
```

### 2.4 Blast Radius Assessment

| 环境 | 暴露面 | 检查状态 | 备注 |
|---|---|---|---|
| 终端（办公PC） | 🔴 高 | ☐ 待检查 | 银狐首要攻击目标，重点排查财务/人事/税务岗位 |
| 终端（开发机） | 🟡 中 | ☐ 待检查 | 可能通过群聊文件波及 |
| 邮件网关 | 🟡 中 | ☐ 待检查 | 钓鱼邮件投递通道 |
| IM工具（微信/企微） | 🔴 高 | ☐ 待检查 | 90%+攻击通道，需审计文件传输记录 |
| 内网服务器 | 🟡 中 | ☐ 待检查 | 横向移动可能波及 |
| Active Directory | 🟡 中 | ☐ 待检查 | 凭据窃取后可能横向扩散 |
| 云环境 | 🟢 低 | ☐ 待检查 | 除非终端有云凭据 |

---

## 3 · The Highlight

> *攻击者最聪明的设计 — 以及分析中最棘手的环节。*

### 3.1 Attacker's Clever Move

银狐家族最聪明的设计不是单一技术突破，而是**对"信任链"的极致劫持**：

**白加黑的信任套娃：**
银狐将恶意DLL放在 `C:\Program Files\Internet Explorer\` 这个Windows自带、杀软天然信任的目录下，然后用合法的 `installer.exe`（带数字签名的白文件）去加载。安全产品看到的是"IE目录下的合法程序加载了一个DLL"——这在Windows系统中再正常不过了。**攻击者没有写任何恶意PE文件，他们只是把恶意代码放到了一个"不该被怀疑"的地方。**

**合法远控的武器化：**
AnyDesk是一个被IT运维人员广泛使用、拥有合法数字签名的远程控制软件。银狐静默安装它并设置无人值守访问后，安全团队看到的是"一个合法远控软件在运行"——这不是恶意软件，这是一个被恶意使用的合法工具。**这让基于签名和黑白名单的安全体系彻底失效。**

**社会工程学的精准打击：**
银狐的诱饵不是"恭喜你中奖了"这种低级骗术，而是精确复刻的公文格式——"2026年第二季度违纪名单""裁员补偿方案""税务稽查通知"。**它攻击的不是系统漏洞，而是人在面对权威信息（违纪、裁员、稽查）时的恐慌本能。** 高阶操纵者甚至会根据企业组织架构跳过安全部门，只针对财务和人事人员。

**产业化分工的效率：**
从木马开发、免杀更新（按周迭代）、诱饵制作、批量投递到诈骗变现，每个环节都有专业团队。攻击者只需花几百元购买授权就能发起大规模攻击。**这不是技术对抗，这是商业模式对抗。**

### 3.2 The Analyst's Insight

在实际分析银狐样本时，最棘手的环节是**无文件攻击的取证**：

- Shellcode全程在内存中执行，不写入磁盘，传统基于文件的检测完全失效
- 进程注入到 `explorer.exe` / `svchost.exe` 后，从进程列表看完全合法
- 计划任务的命名模仿系统更新，触发频率高但每次执行时间极短
- C2通信采用AES-256全加密，流量分析无法获取明文内容

**破解的关键数据点：** `C:\Program Files\Internet Explorer\` 目录下出现非系统自带的DLL文件（如 `log.dll`）——这个目录正常情况下不应该有第三方DLL。**一个不该存在的文件，出现在一个不该出现的地方，这就是银狐的"阿喀琉斯之踵"。**

### 3.3 Lesson Learned

银狐的崛起标志着网络攻击从**"技术驱动"转向"人性驱动"**。它证明了一个事实：**企业花费数百万搭建的安全防线，可以被一个精心设计的"违纪名单"轻松绕过。**

对抗银狐的核心逻辑不在于杀毒库有多全、防火墙规则有多严，而在于能否守住人性的弱点——当我们收到"税务稽查通知"时，能否先核实发件人身份？当我们看到"裁员补偿方案"时，能否先确认文件扩展名？当我们接到领导的转账指令时，能否打个电话再确认一下？

**这些看似简单的动作，往往就是抵御银狐攻击最有效的防线。**

---

## 4 · The Recommendations

> *Strategic recommendations to permanently harden defenses.*

### 4.1 Immediate Actions (0–72 hours)

| Priority | Action | Owner | Status |
|---|---|---|---|
| 🔴 P0 | 全网排查 `C:\Program Files\Internet Explorer\` 目录下是否存在异常DLL（log.dll等） | SOC | ☐ |
| 🔴 P0 | 在防火墙/代理上封禁已知C2 IP和域名（见IoC列表），阻断端口8880出站 | 网络安全 | ☐ |
| 🔴 P0 | 全网排查可疑计划任务（"Adobe Updater"/"Windows Update"等高频任务） | SOC | ☐ |
| 🔴 P0 | 检查终端是否静默安装AnyDesk/TeamViewer，如有立即隔离 | IT运维 | ☐ |
| 🟡 P1 | 排查财务/人事/税务岗位人员终端，优先级最高 | SOC | ☐ |
| 🟡 P1 | 通知全员警惕"违纪名单""裁员补偿"等主题文件，暂停打开可疑IM文件 | 全员 | ☐ |
| 🟡 P1 | 使用国家计算机病毒协同分析平台（virus.cverc.org.cn）上传可疑样本检测 | SOC | ☐ |

### 4.2 Short-Term Hardening (1–4 weeks)

- [ ] **部署检测规则**：将第2.3节的检测查询部署到SIEM/EDR，开启告警
- [ ] **启用Sysmon**：全网部署Sysmon，开启进程创建(Event 1)、网络连接(Event 3)、DLL加载(Event 7)、计划任务(Event 11)日志
- [ ] **PowerShell日志增强**：开启脚本块日志（Event 4103/4104），记录所有PS执行
- [ ] **IM安全网关**：部署企业微信/钉钉文件传输审计，拦截.exe/.scr/.bat等可执行文件
- [ ] **EDR行为检测**：开启计划任务创建监控、注册表Run键修改监控、进程注入检测、合法远控软件安装告警
- [ ] **全员安全意识培训**：专项讲解银狐木马识别方法，进行模拟钓鱼演练
- [ ] **财务流程加固**：所有转账操作必须多人审批+电话/当面核实，禁止仅通过IM下达转账指令

### 4.3 Long-Term Strategic Improvements

| 领域 | 建议 | 实施难度 | 影响 |
|---|---|---|---|
| **终端防护** | 全网部署EDR/XDR，开启行为检测、内存扫描、威胁狩猎 | 高 | 高 |
| **应用控制** | 启用应用程序白名单，禁止非授权.exe执行 | 高 | 高 |
| **网络分段** | 关键业务区域（财务/人事）实施零信任网络隔离 | 高 | 高 |
| **邮件安全** | 部署AI驱动的邮件安全网关，检测钓鱼邮件和恶意附件 | 中 | 高 |
| **IM管控** | 企业IM工具禁止传输可执行文件，或强制沙箱打开 | 中 | 高 |
| **威胁情报** | 接入银狐家族实时威胁情报，自动更新IoC阻断策略 | 中 | 中 |
| **应急演练** | 每季度进行银狐攻击场景的桌面推演和实战演练 | 低 | 中 |
| **蓝队检测** | 建立银狐专项检测规则库，定期更新（银狐免杀按周迭代） | 中 | 高 |

### 4.4 Detection Engineering

#### YARA Rule — SilverFox 白利用载荷检测

```yara
rule SilverFox_WhiteListing_DLL {
    meta:
        description = "Detects SilverFox malicious DLL placed in IE directory for white-listing bypass"
        author = "Security Analyst"
        date = "2026-06-11"
        reference = "https://www.cverc.org.cn/head/zhaiyao/news20260521-yhyj.htm"
    strings:
        $path1 = "Program Files\\Internet Explorer" ascii wide nocase
        $dll_name = "log.dll" ascii wide
        $export1 = "DllRegisterServer" ascii wide
        $export2 = "DllInstall" ascii wide
        // 高熵特征：极简导入 + 大量导出函数
    condition:
        uint16(0) == 0x5A4D
        and filesize < 500KB
        and $dll_name
        and 1 of ($export*)
}
```

#### YARA Rule — SilverFox Chrome 变种

```yara
rule SilverFox_Chrome_Variant {
    meta:
        description = "SilverFox Chrome variant - PowerShell AMSI bypass + reflective loading"
        author = "EDR实战派"
        date = "2026-05-13"
    strings:
        $pdb1 = "XiaobaoService.pdb" ascii wide
        $pdb2 = "Androws\\p-" ascii wide
        $a1 = "XiaobaoService" ascii wide
        $a2 = "ABoxHeadless.exe" ascii wide
        $a3 = "qimei.dll" ascii wide
    condition:
        uint16(0) == 0x5A4D and 2 of them
}
```

#### YARA Rule — 高熵无特征DLL

```yara
rule SilverFox_HighEntropy_DLL {
    meta:
        description = "High entropy .text section with minimal imports - SilverFox shellcode loader pattern"
    condition:
        uint16(0) == 0x5A4D
        and pe.DLL
        and pe.number_of_imports == 1
        and pe.number_of_exports > 100
        and for any i in (0..pe.number_of_sections - 1): (
            pe.sections[i].name == ".text"
            and math.entropy(pe.sections[i].pointer_to_raw_data, pe.sections[i].raw_data_size) > 7.0
        )
}
```

#### Sigma Rule — 计划任务持久化检测

```yaml
title: SilverFox - Suspicious Scheduled Task Creation
id: b2c3d4e5-f6a7-8901-bcde-f12345678901
status: experimental
description: Detects creation of scheduled tasks mimicking system update names, used by SilverFox for persistence
references:
  - https://www.cverc.org.cn/head/zhaiyao/news20260521-yhyj.htm
author: Security Analyst
date: 2026-06-11
logsource:
  product: windows
  category: process_creation
detection:
  selection:
    Image|endswith: '\schtasks.exe'
    CommandLine|contains|all:
      - '/create'
      - '/sc'
  filter_suspicious_names:
    CommandLine|contains:
      - 'Adobe Updater'
      - 'Windows Update'
      - 'System Check'
      - 'Security Update'
      - 'GoogleUpdate'
      - 'MicrosoftEdgeUpdate'
  condition: selection and filter_suspicious_names
level: high
tags:
  - attack.persistence
  - attack.t1053.005
```

---

## Appendix

### A. 国家计算机病毒协同分析平台样本查询

可通过以下平台查询银狐样本的详细分析报告：
- **国家计算机病毒协同分析平台**: https://virus.cverc.org.cn
- 上传可疑文件即可获取多引擎检测结果和行为分析

### B. 银狐家族主流变种对比

| 变种 | 核心技术 | 主要功能 | 活跃时间 |
|---|---|---|---|
| **ValleyRAT（基础远控）** | Go/Rust加载器 + 内存Shellcode | 完整远控功能 | 2020至今 |
| **Python Stealer** | Python编写 | 专注窃密，完成后自删除 | 2026.02至今 |
| **AnyDesk联合变种** | 银狐+AnyDesk静默安装 | 桌面接管+冒充领导诈骗 | 2025至今 |
| **ABCDoor** | Python，双重持久化 | 对抗EDR，高级持久化 | 2025底至今 |
| **Chrome变种** | PowerShell AMSI绕过 + 反射式加载 | 无文件攻击，反沙箱 | 2026.05至今 |

### C. References

1. [国家计算机病毒应急处理中心 — 银狐系列木马预警报告（2026-05-21）](https://www.cverc.org.cn/head/zhaiyao/news20260521-yhyj.htm)
2. [SilverFox家族木马远控全解析 — CSDN（2026-06-01）](https://blog.csdn.net/T_RAFFORD/article/details/161583350)
3. [深度拆解银狐木马：七阶段攻击链与防御盲区分析 — FreeBuf（2026-03-28）](https://www.freebuf.com/articles/endpoint/475315.html)
4. [从Silver Fox新变种看2026年网络钓鱼的攻防进化 — CSDN（2026-05-21）](https://blog.csdn.net/fireroothacker/article/details/161219110)
5. [银狐木马Chrome变种分析 — FreeBuf（2026-05-14）](https://www.freebuf.com/articles/481194.html)
6. [银狐（SilverFox）黑产组织详细分析报告 — ZONE.CI（2026-04-30）](https://security.zone.ci/secarticles/wx/527189.html)
7. [双重间谍活动的战术演进：Silver Fox组织攻击模式深度分析 — 腾讯云（2026-03-26）](https://cloud.tencent.com/developer/article/2646665)
8. [揭秘银狐组织利用SEO投毒分发ValleyRAT的攻击活动 — FreeBuf（2025-12-21）](https://www.freebuf.com/articles/web/463288.html)
9. [国家互联网应急中心发布关于"游蛇"黑产攻击活动风险提示（2025-05-23）](https://www.toutiao.com/article/7507571918468317708/)
10. [银狐木马技术原理分析与检测技术 — CSDN（2025-11-05）](https://blog.csdn.net/bdfcfff77fa/article/details/154440643)
11. [Silver Fox 银狐的攻击组织在2025-2026攻击趋势及关键IOC — CN-SEC（2026-03-27）](https://cn-sec.com/archives/5132986.html)
12. [SilverFox组织仿印度税务部门钓鱼攻击机理与防御研究 — 百家号（2026-05-12）](https://baijiahao.baidu.com/s?id=1864943954776601667)
13. [MITRE ATT&CK — Phishing: Spearphishing via Service (T1566.003)](https://attack.mitre.org/techniques/T1566/003/)
14. [MITRE ATT&CK — Process Injection (T1055)](https://attack.mitre.org/techniques/T1055/)
15. [国家计算机病毒协同分析平台](https://virus.cverc.org.cn)

### D. Changelog

| Date | Author | Change |
|---|---|---|
| 2026-06-11 | Security Analyst | Initial draft — 基于国家病毒中心预警报告和公开技术分析 |
| 2026-06-11 | Security Analyst | 新增 §0 Background — 银狐溯源与变种演化史（起源、组织架构、9大变种、免杀五代演进、双重间谍模式） |

---

*Published 2026-06-11 · Based on CVERC Advisory 2026-05-21*
*Sources: 国家计算机病毒应急处理中心、安天科技、瑞星网安、奇安信、绿盟科技*
