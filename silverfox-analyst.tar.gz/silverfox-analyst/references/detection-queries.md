# SilverFox Detection Queries

> 覆盖 Splunk / Elastic / Sentinel / CrowdStrike Falcon / Sigma / YARA

## Splunk

### 检测伪装文件执行（诱饵）

```spl
index=sysmon EventCode=1
| where ParentImage IN ("*explorer.exe", "*wechat.exe", "*wxwork.exe", "*qq.exe")
| where (Image LIKE "%.exe" AND (
    match(OriginalFileName, "(?i)(名单|违纪|裁员|补偿|稽查|通报|调查)")
    OR match(CommandLine, "(?i)(名单|违纪|裁员|补偿|稽查|通报|调查)")
))
| stats count by Computer, User, ParentImage, Image, CommandLine, Hashes
```

### 检测白利用路径异常DLL

```spl
index=sysmon EventCode=7
| where ImageLoaded LIKE "C:\\Program Files\\Internet Explorer\\%"
| where NOT match(ImageLoaded, "(?i)(ieproxy\.dll|iertutil\.dll)")
| stats count by Computer, Image, ImageLoaded, Signed, Signature
```

### 检测C2回联（端口8880）

```spl
index=firewall OR index=proxy dest_port=8880
| stats count values(dest_ip) as dest_ips by src_ip
| where count > 3
```

### 检测可疑计划任务创建

```spl
index=sysmon EventCode=1 Image="*schtasks.exe"
| regex(CommandLine, "(?i)(Adobe Updater|Windows Update|System Check|Security Update)")
| stats count by Computer, User, CommandLine, ParentImage
```

### 检测计划任务执行

```spl
index=sysmon EventCode=1 ParentImage="*taskeng.exe" OR ParentImage="*svchost.exe"
| where Image LIKE "%Temp%" OR Image LIKE "%AppData%"
| stats count by Computer, User, Image, ParentImage, CommandLine
```

### 检测AnyDesk静默安装

```spl
index=sysmon EventCode=1
| where Image LIKE "%AnyDesk%" OR CommandLine LIKE "%AnyDesk%"
| where match(CommandLine, "(?i)(--install|--start-with-win|--silent|--set-password)")
| stats count by Computer, User, Image, CommandLine
```

### 检测PowerShell无文件攻击

```spl
index=sysmon EventCode=1 Image="*powershell.exe"
| where match(CommandLine, "(?i)(Invoke-Expression|IEX|FromBase64|EncodedCommand|Net\.WebClient|DownloadString|DownloadFile|Reflection\.Assembly|LoadWithPartialName)")
| stats count by Computer, User, CommandLine, ParentImage
```

### 检测进程注入（异常父子关系）

```spl
index=sysmon EventCode=1
| where (Image LIKE "%mshta.exe" OR Image LIKE "%rundll32.exe" OR Image LIKE "%regsvr32.exe")
| where NOT (ParentImage LIKE "%explorer.exe" OR ParentImage LIKE "%svchost.exe")
| stats count by Computer, User, Image, ParentImage, CommandLine
```

## Elastic (KQL)

### 检测伪装文件执行

```kql
event.dataset: * AND (
  process.name: *.exe AND (
    process.command_line: *违纪* OR
    process.command_line: *裁员* OR
    process.command_line: *补偿* OR
    process.command_line: *稽查* OR
    process.command_line: *通报*
  )
)
```

### 检测端口8880出站

```kql
event.dataset: * AND destination.port: 8880
```

### 检测AnyDesk安装

```kql
event.dataset: * AND (
  process.name: "AnyDesk.exe" AND
  process.command_line: ("--install" OR "--start-with-win" OR "--silent")
)
```

### 检测IE目录异常DLL加载

```kql
event.dataset: * AND (
  dll.path: "C:\\Program Files\\Internet Explorer\\*" AND
  NOT dll.name: ("ieproxy.dll" OR "iertutil.dll")
)
```

## Microsoft Sentinel (KQL)

### 检测白利用进程链

```kql
DeviceProcessEvents
| where FileName in~ ("mshta.exe", "rundll32.exe", "regsvr32.exe")
| where InitiatingProcessFileName !~ "explorer.exe"
| join kind=inner DeviceNetworkEvents on DeviceId, InitiatingProcessId
| where RemotePort == 8880 or RemotePort == 443
| project Timestamp, DeviceName, FileName, InitiatingProcessFileName, RemoteIP, RemotePort
```

### 检测可疑计划任务

```kql
DeviceProcessEvents
| where FileName =~ "schtasks.exe"
| where ProcessCommandLine has_any ("Adobe Updater", "Windows Update", "System Check", "Security Update")
| project Timestamp, DeviceName, AccountName, ProcessCommandLine
```

### 检测IE目录异常文件

```kql
DeviceFileEvents
| where FolderPath startswith @"C:\Program Files\Internet Explorer\"
| where FileName !in~ ("iexplore.exe", "ieproxy.dll", "iertutil.dll", "ieinstal.exe")
| project Timestamp, DeviceName, FileName, ActionType, InitiatingProcessFileName
```

### 检测AnyDesk静默安装

```kql
DeviceProcessEvents
| where FileName =~ "AnyDesk.exe"
| where ProcessCommandLine has_any ("--install", "--start-with-win", "--silent", "--set-password")
| project Timestamp, DeviceName, AccountName, ProcessCommandLine
```

## CrowdStrike Falcon

### 检测C2回联

```
#event_simpleName=NetworkConnect* RemotePort=8880
| groupBy([aid, ComputerName, RemoteAddressIP4], function=([count(aid)]))
```

### 检测IE目录DLL加载

```
#event_simpleName=LoadImage
| ImageLoaded=*\Internet Explorer\*.dll
| groupBy([aid, ComputerName, ImageLoaded], function=([count(aid)]))
```

### 检测可疑计划任务

```
#event_simpleName=ScheduledTaskCreated
| TaskName=("*Adobe Updater*" OR "*Windows Update*" OR "*System Check*")
| groupBy([aid, ComputerName, TaskName, UserName], function=([count(aid)]))
```

### 检测AnyDesk安装

```
#event_simpleName=ProcessRollup2
| FileName="AnyDesk.exe"
| CommandLine=*"--install"* OR CommandLine=*"--silent"*
| groupBy([aid, ComputerName, UserName, CommandLine], function=([count(aid)]))
```

## Sigma Rules

### 诱饵执行检测

```yaml
title: SilverFox - Suspicious Executable Masquerading as Document
id: a1b2c3d4-e5f6-7890-abcd-ef1234567890
status: experimental
description: >
  Detects execution of executable files with document-related keywords
  characteristic of SilverFox social engineering attacks.
references:
  - https://www.cverc.org.cn/head/zhaiyao/news20260521-yhyj.htm
author: Security Analyst
date: 2026-06-11
logsource:
  category: process_creation
  product: windows
detection:
  selection_keywords:
    CommandLine|contains:
      - '违纪'
      - '裁员'
      - '补偿'
      - '稽查'
      - '通报'
      - '调查结果'
      - '人员信息'
  selection_extension:
    CommandLine|endswith:
      - '.exe'
      - '.scr'
      - '.bat'
  filter_legitimate:
    ParentImage|endswith:
      - '\explorer.exe'
  condition: selection_keywords and selection_extension and not filter_legitimate
level: high
tags:
  - attack.execution
  - attack.t1204.002
  - attack.initial_access
  - attack.t1566.003
```

### 计划任务持久化检测

```yaml
title: SilverFox - Suspicious Scheduled Task Creation
id: b2c3d4e5-f6a7-8901-bcde-f12345678901
status: experimental
description: >
  Detects creation of scheduled tasks mimicking system update names,
  used by SilverFox for persistence.
references:
  - https://www.cverc.org.cn/head/zhaiyao/news20260521-yhyj.htm
author: Security Analyst
date: 2026-06-11
logsource:
  product: windows
  category: process_creation
detection:
  selection:
    Image|endswith: '\schtasks.exe'
    CommandLine|contains|all:
      - '/create'
      - '/sc'
  filter_suspicious_names:
    CommandLine|contains:
      - 'Adobe Updater'
      - 'Windows Update'
      - 'System Check'
      - 'Security Update'
      - 'GoogleUpdate'
      - 'MicrosoftEdgeUpdate'
  condition: selection and filter_suspicious_names
level: high
tags:
  - attack.persistence
  - attack.t1053.005
```

### C2通信检测

```yaml
title: SilverFox - C2 Communication on Port 8880
id: c3d4e5f6-a7b8-9012-cdef-123456789012
status: experimental
description: >
  Detects outbound HTTP connections on port 8880,
  a known SilverFox C2 communication port.
references:
  - https://www.cverc.org.cn/head/zhaiyao/news20260521-yhyj.htm
author: Security Analyst
date: 2026-06-11
logsource:
  category: network_connection
  product: windows
detection:
  selection:
    DestinationPort: 8880
    Initiated: 'true'
  condition: selection
level: high
tags:
  - attack.command_and_control
  - attack.t1571
```

## YARA Rules

### 白利用载荷检测

```yara
rule SilverFox_WhiteListing_DLL {
    meta:
        description = "SilverFox malicious DLL in IE directory for white-listing bypass"
        author = "Security Analyst"
        date = "2026-06-11"
        reference = "https://www.cverc.org.cn/head/zhaiyao/news20260521-yhyj.htm"
    strings:
        $dll_name = "log.dll" ascii wide
        $export1 = "DllRegisterServer" ascii wide
        $export2 = "DllInstall" ascii wide
    condition:
        uint16(0) == 0x5A4D
        and filesize < 500KB
        and $dll_name
        and 1 of ($export*)
}
```

### Chrome变种检测

```yara
rule SilverFox_Chrome_Variant {
    meta:
        description = "SilverFox Chrome variant with PowerShell AMSI bypass"
        author = "EDR Analyst"
        date = "2026-05-13"
    strings:
        $pdb1 = "XiaobaoService.pdb" ascii wide
        $pdb2 = "Androws\\p-" ascii wide
        $a1 = "XiaobaoService" ascii wide
        $a2 = "ABoxHeadless.exe" ascii wide
        $a3 = "qimei.dll" ascii wide
    condition:
        uint16(0) == 0x5A4D and 2 of them
}
```

### 高熵无特征DLL

```yara
rule SilverFox_HighEntropy_DLL {
    meta:
        description = "High entropy .text with minimal imports - SilverFox shellcode loader"
    condition:
        uint16(0) == 0x5A4D
        and pe.DLL
        and pe.number_of_imports == 1
        and pe.number_of_exports > 100
        and for any i in (0..pe.number_of_sections - 1): (
            pe.sections[i].name == ".text"
            and math.entropy(pe.sections[i].pointer_to_raw_data, pe.sections[i].raw_data_size) > 7.0
        )
}
```
