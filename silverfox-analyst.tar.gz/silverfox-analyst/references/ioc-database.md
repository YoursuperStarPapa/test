# SilverFox IoC Database

> 最后更新：2026-06-11 · 来源：国家计算机病毒应急处理中心预警报告（2026-05-21）

## 1. 文件名模式

诱饵文件命名规律（均为.exe，伪装成文档/文件夹）：

```
2026*违纪*名单*.exe
2026*裁员*补偿*.exe
2026*内部调查*.exe
2026*通报*人员*.exe
2026*税务*稽查*.exe
2026*员工*津贴*.exe
2026*工资*调整*.exe
*违纪*名单*pdf.exe
*裁员*方案*pdf.exe
*补偿*方案*pdf.exe
```

## 2. 文件路径

| 路径 | 文件 | 用途 |
|---|---|---|
| `C:\Program Files\Internet Explorer\` | `log.dll` | 白利用载荷（恶意DLL） |
| `C:\Program Files\Internet Explorer\` | `installer.exe` | 白文件加载器（合法签名） |
| `C:\Program Files\Common Files\` | `update.dll`, `service.dll` | 变种载荷 |
| `%Temp%` / `%AppData%` / `%LocalAppData%` | 随机命名的.tmp/.dll文件 | 临时载荷 |
| `%AppData%` / `%LocalAppData%` | 随机命名的.exe | 持久化副本 |

## 3. 文件哈希（MD5）

### 3.1 2026年5月预警报告样本

```
18685800b70e3e30f54d1a5fa1c4b080
e28fee7fccbab8e743d953383a52c8e4
245aee2442aab596271add1f62099ec0
6d51a96545f8a3e15308ef8683f64077
cb9e0290c31a6cbc2c04eaa010c49c62
8f785cb7955fb2d7b0914fc8e1e85e1a
365d79c4976c4266e8a928a291ce70bd
803fe35653cb4018b56d27e5e130c2d2
44b2de1f5d9c40947ecf0b5bc6ade7c5
02ff385debe958e1125fae9191579b87
52f76f79bf8bd301bad98d73e52c9bca
dc76c6ff76f78a66e7b242b3a02836c6
04386776404ca093758217563c1777b3
6caeaf0e58bb53ca6493ec177090fe37
f81a6f17cb9956a66691805af740f9cc
c8df90c28d202c86f549a03a3bb0a3b0
8c03767c3aee70dfe3f26ea26a47fbf4
af64a60ce7409a82976bceb2c22b0c11
a7f5813610510c8a4aeef8f4fb0d984e
586246a1b852db9a61c61aabb92e7dd9
```

## 4. C2 域名

```
gi***ks.cn
eea*****fbng.cn
ccc******gnsd.cn
wwn******dsrf.cn
tyr*****rbvv.cn
ttc***jiue.cn
tts****gsdf.cn
```

## 5. C2 URL 模式

```
http://[域名]:8880/
http://[域名]:8880/getinstall64
```

**关键特征**：端口 **8880** 是银狐C2通信的标志性端口。

## 6. C2 IP 地址

```
95.*.*.166
154.*.*.180
154.*.*.78
38.*.*.243
18.*.*.122
95.*.*.247
20.*.*.9
43.*.*.243
16.*.*.143
95.*.*.178
```

## 7. 计划任务特征

伪装名称（高频触发，每1-5分钟）：

```
Adobe Updater
Windows Update
System Check
Security Update
GoogleUpdate
MicrosoftEdgeUpdate
```

**识别要点**：
- 触发频率异常高（≤5分钟）
- 执行程序指向 `%Temp%` 或 `%AppData%` 下的可疑文件
- 创建时间在非工作时段

## 8. 注册表特征

```
HKCU\Software\Microsoft\Windows\CurrentVersion\Run  → 可疑启动项
HKLM\Software\Microsoft\Windows\CurrentVersion\Run  → 可疑启动项
```

特征：随机字母+数字命名的项名。

## 9. 进程特征

### 9.1 异常系统工具进程

```
mshta.exe    — 父进程非explorer.exe
rundll32.exe — 加载非系统DLL
regsvr32.exe — 注册非系统DLL
powershell.exe — 执行内存加载/.NET CLR
```

### 9.2 Chrome变种特征

```
PDB路径: XiaobaoService.pdb
进程名: ABoxHeadless.exe
DLL名: qimei.dll
```

### 9.3 合法远控（被滥用）

```
AnyDesk.exe — 静默安装 + 无人值守
TeamViewer.exe — 非用户主动安装
UltraViewer.exe — 非用户主动安装
HoldingHands — 合法远控被武器化
```

## 10. 网络通信特征

| 特征 | 值 |
|---|---|
| C2端口 | **8880** |
| 加密算法 | AES-256 |
| 流量伪装 | HTTP/HTTPS，模仿浏览器User-Agent |
| 通信模式 | 短连接，每次通信后断开 |
| 域名特征 | 随机无意义字符串 / CDN / 云服务域名 |

## 11. YARA 特征字符串

```
XiaobaoService.pdb
Androws\p-
XiaobaoService
ABoxHeadless.exe
qimei.dll
log.dll
DllRegisterServer
DllInstall
```
