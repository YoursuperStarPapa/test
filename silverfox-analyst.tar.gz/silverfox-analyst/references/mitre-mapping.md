# SilverFox MITRE ATT&CK Mapping

> 完整的银狐木马ATT&CK战术-技术映射

## 战术概览

```
Initial Access → Execution → Persistence → Defense Evasion → Discovery → Credential Access → Collection → C2 → Exfiltration → Impact
```

## 详细映射

### TA0001 Initial Access

| Technique | ID | 银狐实现 |
|---|---|---|
| Phishing: Spearphishing via Service | T1566.003 | 通过微信/企业微信/QQ群聊发送伪装文件 |
| Phishing: Spearphishing Attachment | T1566.001 | 邓件发送含恶意附件的钓鱼邮件 |
| Phishing: Spearphishing Link | T1566.002 | 发送钓鱼链接（SEO投毒/二维码） |

### TA0002 Execution

| Technique | ID | 银狐实现 |
|---|---|---|
| User Execution: Malicious File | T1204.002 | 用户双击伪装成文档的exe |
| Command and Scripting Interpreter: PowerShell | T1059.001 | 内存加载.NET CLR执行恶意代码 |
| Command and Scripting Interpreter: Windows Command Shell | T1059.003 | cmd.exe执行系统命令 |
| Inter-Process Communication | T1559 | 利用COM对象执行代码 |
| Native API | T1106 | 直接调用Windows API |

### TA0003 Persistence

| Technique | ID | 银狐实现 |
|---|---|---|
| Scheduled Task/Job: Scheduled Task | T1053.005 | 创建伪装计划任务（Adobe Updater等），每1-5分钟执行 |
| Boot or Logon Autostart Execution: Registry Run Keys | T1547.001 | HKCU/HKLM\Run键持久化 |
| Create or Modify System Process: Windows Service | T1543.003 | 创建随机名称系统服务 |
| Boot or Logon Autostart Execution: Startup Folder | T1547.001 | 启动文件夹快捷方式 |

### TA0005 Defense Evasion

| Technique | ID | 银狐实现 |
|---|---|---|
| Process Injection | T1055 | 反射式DLL注入/APC注入/进程空心化 |
| Process Injection: Reflective DLL Injection | T1055.001 | 内存加载恶意DLL |
| Process Injection: APC Queueing | T1055.004 | APC队列注入系统进程 |
| Process Injection: Process Hollowing | T1055.012 | 进程空心化 |
| Masquerading | T1036 | 文件名伪装（加pdf后缀、图标伪装） |
| Masquerading: Match Legitimate Name or Location | T1036.005 | 文件放在IE目录下伪装 |
| Signed Binary Proxy Execution: Rundll32 | T1218.011 | rundll32加载恶意DLL |
| Signed Binary Proxy Execution: Mshta | T1218.005 | mshta执行恶意脚本 |
| Signed Binary Proxy Execution: Regsvr32 | T1218.010 | regsvr32注册恶意COM |
| Indicator Removal | T1070 | 攻击结束后卸载AnyDesk、清除痕迹 |
| Indicator Removal: File Deletion | T1070.004 | Python Stealer完成后自删除 |
| Virtualization/Sandbox Evasion | T1497 | 检测50+虚拟机/沙箱特征 |
| Virtualization/Sandbox Evasion: System Checks | T1497.001 | 硬件信息/进程列表/注册表检查 |
| Deobfuscate/Decode Files or Information | T1140 | Shellcode解密执行 |
| Impair Defense: Disable or Modify Tools | T1562.001 | ABCDoor变种可禁用EDR/杀软 |
| Impair Defense: Disable or Modify System Firewall | T1562.004 | 禁用Windows防火墙 |
| Obfuscated Files or Information | T1027 | 代码混淆、控制流扁平化 |
| Obfuscated Files or Information: Software Packing | T1027.002 | 加壳保护 |

### TA0007 Discovery

| Technique | ID | 银狐实现 |
|---|---|---|
| System Network Configuration Discovery | T1016 | 上报IP、计算机名、系统版本 |
| Remote System Discovery | T1018 | 内网存活主机扫描 |
| System Information Discovery | T1082 | 收集系统版本、已安装软件 |
| System Owner/User Discovery | T1033 | 获取当前用户名 |
| Process Discovery | T1057 | 枚举运行进程（检测安全软件） |
| Software Discovery | T1518 | 检测已安装杀软和安全工具 |
| File and Directory Discovery | T1083 | 扫描敏感文件目录 |

### TA0006 Credential Access

| Technique | ID | 银狐实现 |
|---|---|---|
| Credentials from Password Stores | T1555 | 窃取浏览器保存的密码 |
| Credentials from Password Stores: Credentials from Web Browsers | T1555.003 | 提取Chrome/Edge SQLite数据库 |
| Input Capture: Keylogging | T1056.001 | 键盘记录 |
| Steal Web Session Cookie | T1539 | 窃取浏览器Cookie |

### TA0009 Collection

| Technique | ID | 银狐实现 |
|---|---|---|
| Screen Capture | T1113 | 屏幕监控与截图 |
| Input Capture: Keylogging | T1056.001 | 键盘记录 |
| Data from Local System | T1005 | 窃取桌面/文档/下载文件夹文件 |
| Data Staged: Local Data Staging | T1074.001 | 数据打包暂存后上传 |
| Automated Collection | T1119 | 自动扫描并收集敏感文件 |

### TA0011 Command and Control

| Technique | ID | 银狐实现 |
|---|---|---|
| Encrypted Channel | T1573 | AES-256加密C2通信 |
| Encrypted Channel: Asymmetric Cryptography | T1573.002 | 非对称加密通信 |
| Non-Standard Port | T1571 | 端口8880 |
| Remote Access Software | T1219 | 静默安装AnyDesk/TeamViewer/HoldingHands |
| Application Layer Protocol: Web Protocols | T1071.001 | HTTP/HTTPS伪装正常流量 |
| Ingress Tool Transfer | T1105 | 从C2下载功能插件 |
| Proxy: Multi-hop Proxy | T1090.003 | 多层代理隐藏真实C2 |
| Domain Generation Algorithms | T1568 | DGA域名生成 |
| Dynamic Resolution | T1568.001 | CDN/云服务转发C2 |

### TA0010 Exfiltration

| Technique | ID | 银狐实现 |
|---|---|---|
| Exfiltration Over C2 Channel | T1041 | 窃取数据通过C2加密上传 |
| Exfiltration Over Web Service | T1567 | 利用云存储服务上传 |

### TA0040 Impact

| Technique | ID | 银狐实现 |
|---|---|---|
| Financial Theft | — | 冒充领导向财务下达转账指令 |
| Data Encrypted for Impact | T1486 | 部分变种具备勒索能力 |

## 攻击链阶段映射

```
[Initial Access]                    [Execution]                [Persistence]
T1566.003 (IM钓鱼)               T1204.002 (用户执行)         T1053.005 (计划任务)
T1566.001 (邮件钓鱼)             T1059.001 (PowerShell)       T1547.001 (注册表)
                                   T1106 (Native API)          T1543.003 (系统服务)
        ↓                              ↓                           ↓
[Defense Evasion]                   [Discovery]                [Credential Access]
T1055 (进程注入)                   T1016 (网络配置)             T1555.003 (浏览器密码)
T1036 (伪装)                       T1018 (内网扫描)             T1056.001 (键盘记录)
T1218 (白利用)                     T1082 (系统信息)             T1539 (Cookie窃取)
T1497 (反沙箱)                     T1518 (安全软件检测)
T1027 (混淆)                           ↓                           ↓
        ↓                          [Collection]                [C2]
[Exfiltration]                      T1113 (屏幕截图)            T1573 (加密通道)
T1041 (C2上传)                     T1005 (本地文件)             T1571 (端口8880)
T1567 (云服务上传)                 T1056.001 (键盘记录)         T1219 (合法远控)
                                   T1074.001 (数据暂存)         T1071.001 (HTTP)
                                                                T1105 (工具下载)
```
