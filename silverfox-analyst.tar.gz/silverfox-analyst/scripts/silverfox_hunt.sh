#!/bin/bash
# SilverFox Quick Hunt Script
# Usage: silverfox_hunt.sh [--check-all | --check-network | --check-files | --check-tasks | --check-registry]
# Note: Run on Windows (Git Bash/WSL) or remotely via WinRM/SSH

set -euo pipefail

RED='\033[0;31m'
YELLOW='\033[1;33m'
GREEN='\033[0;32m'
NC='\033[0m'

echo "=========================================="
echo "  SilverFox Quick Hunt Script"
echo "  $(date '+%Y-%m-%d %H:%M:%S')"
echo "=========================================="
echo ""

HITS=0

# --- Check 1: IE directory abnormal DLLs ---
echo -e "${YELLOW}[CHECK 1]${NC} C:\\Program Files\\Internet Explorer\\ abnormal DLLs..."
IE_DLLS=$(cmd.exe /c "dir /b \"C:\\Program Files\\Internet Explorer\\*.dll\"" 2>/dev/null | grep -iv "ieproxy\|iertutil\|ieframe\|mshtml\|jscript" || true)
if [ -n "$IE_DLLS" ]; then
    echo -e "${RED}[ALERT]${NC} Found suspicious DLLs in IE directory:"
    echo "$IE_DLLS"
    HITS=$((HITS + 1))
else
    echo -e "${GREEN}[OK]${NC} No abnormal DLLs found."
fi
echo ""

# --- Check 2: Port 8880 connections ---
echo -e "${YELLOW}[CHECK 2]${NC} Outbound connections on port 8880..."
CONN_8880=$(netstat -an 2>/dev/null | grep ":8880" | grep "ESTABLISHED" || true)
if [ -n "$CONN_8880" ]; then
    echo -e "${RED}[ALERT]${NC} Active connections on port 8880 (SilverFox C2):"
    echo "$CONN_8880"
    HITS=$((HITS + 1))
else
    echo -e "${GREEN}[OK]${NC} No connections on port 8880."
fi
echo ""

# --- Check 3: Suspicious scheduled tasks ---
echo -e "${YELLOW}[CHECK 3]${NC} Suspicious scheduled tasks..."
TASKS=$(schtasks /query /fo csv 2>/dev/null | grep -i "Adobe Updater\|Windows Update\|System Check\|Security Update\|GoogleUpdate\|MicrosoftEdgeUpdate" || true)
if [ -n "$TASKS" ]; then
    echo -e "${RED}[ALERT]${NC} Found suspicious scheduled tasks:"
    echo "$TASKS"
    HITS=$((HITS + 1))
else
    echo -e "${GREEN}[OK]${NC} No suspicious scheduled tasks found."
fi
echo ""

# --- Check 4: AnyDesk process (non-user-installed) ---
echo -e "${YELLOW}[CHECK 4]${NC} AnyDesk/TeamViewer processes..."
ANYDESK=$(tasklist 2>/dev/null | grep -i "AnyDesk\|TeamViewer\|UltraViewer" || true)
if [ -n "$ANYDESK" ]; then
    echo -e "${RED}[ALERT]${NC} Remote control software running:"
    echo "$ANYDESK"
    HITS=$((HITS + 1))
else
    echo -e "${GREEN}[OK]${NC} No remote control software detected."
fi
echo ""

# --- Check 5: Suspicious PowerShell activity ---
echo -e "${YELLOW}[CHECK 5]${NC} Recent PowerShell script block events..."
PS_EVENTS=$(wevtutil qe Microsoft-Windows-PowerShell/Operational /c:50 /rd:true /f:text 2>/dev/null | grep -i "FromBase64\|EncodedCommand\|Invoke-Expression\|IEX\|Reflection.Assembly\|Net.WebClient\|DownloadString" | head -5 || true)
if [ -n "$PS_EVENTS" ]; then
    echo -e "${RED}[ALERT]${NC} Suspicious PowerShell activity detected:"
    echo "$PS_EVENTS"
    HITS=$((HITS + 1))
else
    echo -e "${GREEN}[OK]${NC} No suspicious PowerShell activity."
fi
echo ""

# --- Check 6: Registry Run keys ---
echo -e "${YELLOW}[CHECK 6]${NC} Registry Run key persistence..."
REG_HKCU=$(reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" 2>/dev/null | grep -iv "OneDrive\|Microsoft\|Windows\|SecurityHealth\|Steam\|Discord\|Chrome\|Edge\|Firefox" || true)
REG_HKLM=$(reg query "HKLM\Software\Microsoft\Windows\CurrentVersion\Run" 2>/dev/null | grep -iv "OneDrive\|Microsoft\|Windows\|SecurityHealth\|RtkAudUService\|Realtek" || true)
if [ -n "$REG_HKCU" ] || [ -n "$REG_HKLM" ]; then
    echo -e "${YELLOW}[WARN]${NC} Potentially suspicious Run key entries:"
    [ -n "$REG_HKCU" ] && echo "HKCU:" && echo "$REG_HKCU"
    [ -n "$REG_HKLM" ] && echo "HKLM:" && echo "$REG_HKLM"
    HITS=$((HITS + 1))
else
    echo -e "${GREEN}[OK]${NC} No suspicious Run key entries."
fi
echo ""

# --- Summary ---
echo "=========================================="
if [ $HITS -gt 0 ]; then
    echo -e "${RED}[RESULT]${NC} Found $HITS alert(s). Potential SilverFox infection indicators detected!"
    echo ""
    echo "Recommended actions:"
    echo "  1. Disconnect from network immediately"
    echo "  2. Do NOT reboot yet"
    echo "  3. Contact your security team"
    echo "  4. Upload suspicious files to https://virus.cverc.org.cn"
else
    echo -e "${GREEN}[RESULT]${NC} No SilverFox indicators found. System appears clean."
fi
echo "=========================================="
